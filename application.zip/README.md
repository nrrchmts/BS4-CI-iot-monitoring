# BS4-CI-iot-monitoring

Sementara Aplikasi ini hanya berisikan trial &amp; error

- [Update List](https://github.com/nrchmts/BS$-CI-iot-monitoring/README#TODO-List)
- [Update List](https://github.com/nrchmts/BS$-CI-iot-monitoring/README#Referensi)

## TODO List

- tabs dan dropdown pada graph

  - perhari
  - perminggu
  - perbulan
  - pertahun

    .apabila perhari, tampilkan 3 data terbaru pada grafik
    .apabila perminggu, tampilkan 4 data 1 data pertama dan lompat 4 data setelahnya
    .apabila perbulan blblabla

- buat page settings untuk menyesuaikan nilai minimum nilai minimum
  - ini diperlukan untuk pengembangan ke depannya agar dapat digunakan pada hewan lain
- nantikan lagi

## Referensi

- Bootstrap 4.1
- SBAdmin2
- Font Awesome
- dan lainnya
  Untuk semuanya yang tidak disebutkan saya ucapkan terima kasih
